from gtts import gTTS

tts = gTTS(text='hello how are you Im fine', lang='en')
tts.save("aim.mp3")
